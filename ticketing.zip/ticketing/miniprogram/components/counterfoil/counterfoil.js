// compontent/counterfoil.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    oid: {
      type: null,
      value: 0
    },
    title: {
      type: null,
      value: '标题'
    },
    time: {
      type: null,
      value: '时间'
    },
    site: {
      type: null,
      value: '展馆'
    },
    cover: {
      type: null,
      value: '封面'
    },
    type: {
      type: null,
      value: '0'
    },
    status: {
      type: null,
      value: '0'
    }

  },

  /**
   * 组件的初始数据
   */
  data: {
    ticket_list: ["未分类", "普通票", "夜场票", "VIP票", "SVIP票", "预售票", "现场票"],
    ticket_type: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {

  },
  attached: function () {
    var type = this.properties.type;
    var v = this.data.ticket_list[type];
    this.setData({
      ticket_type: v
    })
  }
})
