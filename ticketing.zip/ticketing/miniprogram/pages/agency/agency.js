// miniprogram/pages/agency/agency.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    agency: []
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  onShow() {
    this.getAgencyList();
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.getAgencyList();
  },
  getAgencyList() {
    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('agency').get({
      success: res => {
        this.setData({
          agency: res.data
        })
        wx.stopPullDownRefresh();
        console.log('[数据库] [查询记录] 成功: ', res)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
  },
  onUpdateData: function (id) {
    const self = this;
    const db = wx.cloud.database()
    db.collection('agency').doc(id).update({
      data: {
        status: 2
      },
      success: res => {
        wx.showToast({
          title: '认证成功',
          success: res => {
            this.getAgencyList();
          }
        })
      },
      fail: err => {
        icon: 'none',
          console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },
  onAttestation(e){
    let query = e.currentTarget.dataset['index'];
    let data = this.data.agency[query];
    console.log(data);
    this.onUpdateData(data._id);
  }
})