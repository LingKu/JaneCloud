const app = getApp();
const sql = require('../../utils/sql.js')

Page({
  data: {

  },
  onLoad() {
    this.getDataInfo();
  },
  formSubmit(e) {
    let data = e.detail.value;
    data.status = 1;
    this.onIsertData(data);
  },
  /**
   * 获取文件信息
   */
  async getDataInfo() {
    console.log("sql", sql);
    let table = "";
    let row = await sql.name("agency").where({
      _openid: app.globalData.openid
    }).first();
    if (row) {
      let msg = ""
      if (row.status == 1) {
        msg = "等待管理员审核"
      } else {
        msg = "审核已通过"
      }
      wx.showToast({
        title: msg,
        duration: 1500,
        success: res => {}
      })
      setTimeout(function() {
        wx.navigateBack({
          delta: -1
        })
      }, 1500);
    } else {
      console.log("不存在", row);
    }

  },
  /**
   * 写入数据
   */
  onIsertData(data) {
    //执行数据提交
    const db = wx.cloud.database()
    db.collection('agency').add({
      data: data,
      success: res => {
        wx.hideLoading();
        wx.showToast({
          title: '提交认证成功',
          success: res => {
            wx.navigateBack({
              delta: -1
            })
          }
        })
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '提交认证失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
  },
  tareaAInput(e) {
    this.setData({
      textareaAValue: e.detail.value
    })
  }
})