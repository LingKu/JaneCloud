// miniprogram/pages/cardbag/cardbag.js
const app = getApp()
const sql = require('../../utils/sql.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orders: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  onShow() {
    this.getDataInfo();
  },
  async getDataInfo() {
    let data = await sql.name("orders").where({
      _openid: app.globalData.openid,
      status: 2
    }).select();
    console.log(data);
    this.setData({
      orders: data
    })
    wx.stopPullDownRefresh();
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.getDataInfo();
  },
})