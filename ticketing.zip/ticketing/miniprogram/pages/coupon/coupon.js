// miniprogram/pages/cardbag/cardbag.js
const app = getApp()
const sql = require('../../utils/sql.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order: {},
    order_id: 0,
    roll: 1,
    tear: '../../images/badimg.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options);
    this.getDataInfo(options.order_id);
  },
  async getDataInfo(order_id) {
    let data = await sql.name("orders").where({
      _id: order_id,
      status: 2
    }).first();
    console.log(data);
    this.setData({
      order: data,
      order_id: order_id
    })
    wx.stopPullDownRefresh();
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.getDataInfo(this.data.order_id);
  },
})