// pages/deployFunctions/deployFunctions.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    specClass: 'none',
    tickets: [],
    favorite: true,
    imgList: [{
        src: 'https://gd3.alicdn.com/imgextra/i3/0/O1CN01IiyFQI1UGShoFKt1O_!!0-item_pic.jpg_400x400.jpg'
      },
      {
        src: 'https://gd3.alicdn.com/imgextra/i3/TB1RPFPPFXXXXcNXpXXXXXXXXXX_!!0-item_pic.jpg_400x400.jpg'
      },
      {
        src: 'https://gd2.alicdn.com/imgextra/i2/38832490/O1CN01IYq7gu1UGShvbEFnd_!!38832490.jpg_400x400.jpg'
      }
    ],
    radio: 0,
    number: 1,
    oid: 0,
    icon: {
      normal: 'https://img.yzcdn.cn/vant/user-inactive.png',
      active: 'https://img.yzcdn.cn/vant/user-active.png'
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    if (options.tid) {
      let _data = await this.getTicketsData(options.tid);
      console.log("查询到数据", _data);
      this.setData({
        tickets: _data,
      })
    } else {
      console.log("请选择商品");
    }
  },
  /**
   * 获取更新数据
   */
  async getTicketsData(tid) {
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection('tickets').where({
        _id: tid
      }).get({
        success: function(res) {
          reslove(res.data[0])
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  },
  //规格弹窗开关
  toggleSpec() {
    console.log("执行我了");
    if (this.data.specClass === 'show') {
      this.setData({
        specClass: "hide"
      })
      setTimeout(() => {
        this.setData({
          specClass: "none"
        })
      }, 250);
    } else if (this.data.specClass === 'none') {
      this.setData({
        specClass: "show"
      })
    }
  },
  onChange(event) {
    console.log(event);
    this.setData({
      radio: event.detail
    });
  },
  onChangeNumber(event) {
    console.log(event);
    this.setData({
      number: event.detail
    });
  },
  serOrderInfo() {
    let that = this;
    let formData = e.detail.value
    console.log('form发生了submit事件，携带数据为：', formData)
    wx.cloud.callFunction({
      name: "pay",
      data: {
        orderid: "SN123001928307",
        money: 1
      },
      success(res) {
        console.log("提交成功", res.result)
        that.pay(res.result)
      },
      fail(res) {
        console.log("提交失败", res)
      }
    })
  },
  async formSubmit() {
    let tickets = this.data.tickets.tickets;
    let ticket = tickets[this.data.radio];
    let price = parseFloat(ticket.price);
    let order = {
      type: ticket.type,
      cover: this.data.tickets.cover[0],
      title: this.data.tickets.title,
      address: this.data.tickets.address,
      status: 1,
      start_time: this.data.tickets.start_time,
      end_time: this.data.tickets.end_time,
      time: this.formatTime(new Date()),
      price: ticket.price,
      number: this.data.number,
      money: price * this.data.number * 100
    }
    let resource = await this.addOrder(order);
    this.setData({
      oid: resource._id
    })
    let self = this;
    //执行云函数
    wx.cloud.callFunction({
      name: "pay",
      data: {
        orderid: resource._id,
        money: 1
      },
      success(res) {
        console.log("提交成功", res.result)
        self.pay(res.result)
      },
      fail(res) {
        console.log("提交失败", res)
      }
    })
  },
  onUpdateOrder() {
    let oid = this.data.oid;
    if (oid === 0) {
      console.log("支付出错", this.data);
      return false;
    }
    const db = wx.cloud.database()
    db.collection('orders').doc(oid).update({
      data: {
        status: 2
      },
      success: res => {
        console.log('[数据库] [更新记录] 成功：', res)
        wx.redirectTo({
          url: '/pages/success/pay?oid=' + oid
        })
      },
      fail: err => {
        icon: 'none',
        console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },
  async addOrder(data) {
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection('orders').add({
        data: data,
        success: res => {
          data._id = res._id
          reslove(data)
        },
        fail: err => {
          reject(err)
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  },
  //实现小程序支付
  pay(payData) {
    let self = this;
    //官方标准的支付方法
    wx.requestPayment({
      timeStamp: payData.timeStamp,
      nonceStr: payData.nonceStr,
      package: payData.package, //统一下单接口返回的 prepay_id 格式如：prepay_id=***
      signType: 'MD5',
      paySign: payData.paySign, //签名
      success(res) {
        console.log("支付成功", res)
        self.onUpdateOrder();
      },
      fail(res) {
        console.log("支付失败", res)
      },
      complete(res) {
        console.log("支付完成", res)
      }
    })
  },
  stopPrevent() {},
  formatTime(date) {
    var year = date.getFullYear()
    var month = date.getMonth() + 1
    var day = date.getDate()
    var hour = date.getHours()
    var minute = date.getMinutes()
    var second = date.getSeconds()
    return year + "年" + month + "月" + day + "日" + hour + "时" + minute + "分";
  }
})