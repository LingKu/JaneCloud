// miniprogram/pages/order/order.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    orders: [],
    oid: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      })
    }
  },
  onShow() {
    this.getOrdersList();
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.getOrdersList();
  },
  getOrdersList() {
    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('orders').orderBy('time', 'desc').where({
      _openid: this.data.openid
    }).get({
      success: res => {
        this.setData({
          orders: res.data
        })
        wx.stopPullDownRefresh();
        console.log('[数据库] [查询记录] 成功: ', res)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
  },
  /**
   * 执行订单支付
   */
  onPlayOrder(e) {
    let query = e.currentTarget.dataset['index'];
    let data = this.data.orders[query];
    this.setData({
      oid: data._id
    })
    let that = this;
    wx.cloud.callFunction({
      name: "pay",
      data: {
        orderid: data._id,
        money: 1
      },
      success(res) {
        console.log("提交成功", res.result)
        that.pay(res.result)
      },
      fail(res) {
        console.log("提交失败", res)
      }
    })
  },
  //实现小程序支付
  pay(payData) {
    let self = this;
    //官方标准的支付方法
    wx.requestPayment({
      timeStamp: payData.timeStamp,
      nonceStr: payData.nonceStr,
      package: payData.package, //统一下单接口返回的 prepay_id 格式如：prepay_id=***
      signType: 'MD5',
      paySign: payData.paySign, //签名
      success(res) {
        console.log("支付成功", res)
        self.onUpdateOrder();
      },
      fail(res) {
        console.log("支付失败", res)
      },
      complete(res) {
        console.log("支付完成", res)
      }
    })
  },
  onUpdateOrder() {
    let oid = this.data.oid;
    if (oid === 0) {
      console.log("支付出错", this.data);
      return false;
    }
    const db = wx.cloud.database()
    db.collection('orders').doc(oid).update({
      data: {
        status: 2
      },
      success: res => {
        console.log('[数据库] [更新记录] 成功：', res)
        wx.redirectTo({
          url: '/pages/success/pay?oid=' + oid
        })
      },
      fail: err => {
        icon: 'none',
        console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  }
})