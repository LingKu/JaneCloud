const app = getApp();
Page({
  data: {
    dataInfo: {
      region: ['广东省', '广州市', '海珠区'],
    },
    index: null,
    time: '12:01',
    dateA: '2018-12-25',
    dateB: '2018-12-25',
    region: ['广东省', '广州市', '海珠区'],
    imgList: [],
    tickets: [],
    action: "insert",
    tid: 0
  },
  async onLoad(options) {
    let _key = 0;
    if (options.tid == 0) {
      this.setData({
        action: "insert"
      })
    } else {
      let _data = await this.getUpdateData(options.tid);
      this.setData({
        tid: _data._id,
        action: "update",
        dataInfo: _data,
        imgList: _data.cover,
        tickets: _data.tickets,
      })
      _key = 'ticket' + this.data.tid;
      wx.setStorageSync(_key, _data.tickets);
    }
    if (this.data.action == "insert") {
      _key = 'ticket' + this.data.tid;
      wx.removeStorageSync(_key)
    }
  },
  onShow() {
    let _key = 'ticket' + this.data.tid;
    let _data = wx.getStorageSync(_key);
    console.log("查看数据", _data);
    this.setData({
      tickets: _data
    })
  },
  /**
   * 获取更新数据
   */
  async getUpdateData(tid) {
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection('tickets').where({
        _id: tid
      }).get({
        success: function(res) {
          reslove(res.data[0])
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  },
  async getImageList(fileList) {
    let returned = new Promise(function(reslove, reject) {
      wx.cloud.getTempFileURL({
        fileList: fileList,
        success: res => {
          console.log(res.fileList);
          let data = [];
          for (let i in res.fileList) {
            let item = res.fileList[i];
            data.push(item.tempFileURL);
          }
          reslove(data)
        },
        fail: error => {
          reject(error)
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  },
  /**
   * 更改选择时间
   */
  DateChangeA(e) {
    let _dataInfo = this.data.dataInfo;
    _dataInfo.start_time = e.detail.value
    this.setData({
      dataInfo: _dataInfo
    })
  },
  DateChangeB(e) {
    let _dataInfo = this.data.dataInfo;
    _dataInfo.end_time = e.detail.value
    this.setData({
      dataInfo: _dataInfo
    })
  },
  RegionChange: function(e) {
    let _dataInfo = this.data.dataInfo;
    _dataInfo.region = e.detail.value
    this.setData({
      dataInfo: _dataInfo
    })
  },
  ChooseImage() {
    wx.chooseImage({
      count: 4, //默认9
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album'], //从相册选择
      success: (res) => {
        if (this.data.imgList.length != 0) {
          this.setData({
            imgList: this.data.imgList.concat(res.tempFilePaths)
          })
        } else {
          this.setData({
            imgList: res.tempFilePaths
          })
        }
      }
    });
  },
  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList,
      current: e.currentTarget.dataset.url
    });
  },
  DelImg(e) {
    wx.showModal({
      title: '删除图片',
      content: '确定要删除这张图片吗？',
      cancelText: '取消',
      confirmText: '确认',
      success: res => {
        if (res.confirm) {
          this.data.imgList.splice(e.currentTarget.dataset.index, 1);
          this.setData({
            imgList: this.data.imgList
          })
        }
      }
    })
  },
  /**
   * 提交表单
   */
  async formSubmit(e) {
    wx.showLoading({
      title: '正在保存中……',
    })
    let data = e.detail.value
    data.cover = [];
    //获取封面文件
    let imgList = this.data.imgList;
    for (let i in imgList) {
      let fileID = await this.uploadFile(imgList[i]);
      data.cover.push(fileID);
    }
    data.tickets = this.data.tickets;
    console.log("数据包", data);
    if (this.data.action == "insert") {
      this.onIsertData(data)
    } else {
      this.onUpdateData(data)
    }

  },
  /**
   * 写入数据
   */
  onIsertData(data) {
    //执行数据提交
    const db = wx.cloud.database()
    db.collection('tickets').add({
      data: data,
      success: res => {
        // 在返回结果中会包含新创建的记录的 _id
        this.setData({
          counterId: res._id,
          count: 1
        })
        wx.hideLoading();
        wx.showToast({
          title: '发布门票成功',
          success: res => {
            wx.navigateBack({
              delta: -1
            })
          }
        })
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '发布门票失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
  },
  /**
   * 更新数据
   */
  onUpdateData(data) {
    console.log(data, this.data.tid);
    const db = wx.cloud.database();
    db.collection('tickets').doc(this.data.tid).update({
      data: data,
      success: res => {
        console.log(res);
        wx.hideLoading();
        wx.showToast({
          title: '更新成功',
          success: res => {
            wx.navigateBack({
              delta: -1
            })
          }
        })
      },
      fail: err => {
        console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },
  /**
   * 上传文件
   */
  async uploadFile(file) {
    //判断是否是云端文件 如果是 则直接返回
    let is_file = file.substring(0, 5);
    if (is_file == 'cloud') {
      return file;
    }
    let name = this.createNoncestr(4);
    let returned = new Promise(function(reslove, reject) {
      wx.cloud.uploadFile({
        //文件名
        cloudPath: name,
        //文件路径
        filePath: file,
      }).then(res => {
        reslove(res.fileID)
      }).catch(error => {
        reject(error)
      })
    })
    let fileID = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return fileID;
  },
  /**
   * 随机字符串
   */
  createNoncestr(len = 32, str = "") {
    len = len || 32;
    var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678'; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
    var maxPos = $chars.length;
    var pwd = str;
    for (var i = 0; i < len; i++) {
      pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return pwd + new Date().getTime();
  }
})