// miniprogram/pages/ticket/ticket.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tid: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options);
    this.setData({
      tid: options.tid
    })
  },
  /**
   * 提交表单
   */
  formSubmit(e) {
    let data = e.detail.value
    let _key = 'ticket' + this.data.tid;
    let _data = wx.getStorageSync(_key);
    if (!_data) {
      _data = [];
    }
    _data.push(data)

    wx.setStorageSync(_key, _data)

    wx.navigateBack({
      delta: -1
    })
  }
})