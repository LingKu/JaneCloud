const app = getApp();
const sql = require('../../utils/sql.js')

Page({
  data: {
    avatarUrl: './user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
    admin: 0
  },

  onLoad: function() {
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
    let slef = this;
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              console.log("已经授权，可以直接调用res", res);
              this.onGetAgency();
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo
              })
            }
          })
        }
      }
    })
  },
  async onGetAgency() {
    let row = await sql.name("agency").where({
      _openid: app.globalData.openid
    }).first();
    if (row) {
      if (row.status == 3) {
        this.setData({
          admin: 1
        })
      }
    }
  },
  onGetUserInfo(e) {
    console.log(e)
    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'getOpenData',
        openData: {
          list: [
            e.detail.cloudID,
          ]
        }
      }
    }).then(res => {
      console.log('[onGetUserInfo] 调用成功：', res.result.list[0].data)
      wx.setStorageSync("userInfo", res.result.list[0].data);
      this.onGetAgency();
      this.setData({
        logged: true,
        avatarUrl: res.result.list[0].data.avatarUrl,
        userInfo: res.result.list[0].data
      })
    })
  },
  onGetUserInfo2: function(e) {
    if (!this.data.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  }

})