/*
 * @Author: Sean
 * @Date:   2019-05-31 01:21:32
 * @Last Modified by:   Sean
 * @Last Modified time: 2019-05-31 01:24:45
 */

import {
	hex_md5
} from './md5.js';

export const encrypt = (data, key = "this7") => {
	let char = '';
	let str = '';
	key = hex_md5(key);
	let x = 0;
	let len = data.length;
	let l = key.length;
	for (var i = 0; i < len; i++) {
		if (x == l) {
			x = 0;
		}
		let _char1 = key.charAt(x);
		char = char + _char1;
		x++;
	}
	for (i = 0; i < len; i++) {
		let _data = data.charAt(i);
		let _char = char.charAt(i);
		let _ord_data = _data.charCodeAt(0);
		let _ord_char = _char.charCodeAt(0);
		let _chr = _ord_data + (_ord_char % 246);
		let _str1 = String.fromCharCode(_chr);
		str = str + _str1;
	}
	return btoa(str);
}

export const decrypt = (data, key = "this7") => {


	let char = '';
	let str = '';
	key = hex_md5(key);
	let x = 0;
	data = atob(data);
	let len = data.length;
	let l = key.length;


	for (var i = 0; i < len; i++) {
		if (x == l) {
			x = 0;
		}
		let _char1 = key.substr(x);
		char = char + _char1;
		x++;
	}

	for (i = 0; i < len; i++) {
		let _data = data.substr(i);
		let _char = char.substr(i);

		let _ord_data = _data.charCodeAt(0);
		let _ord_char = _char.charCodeAt(0);
		if (_ord_data < _ord_char) {
			let _chr = _ord_data + 256 - _ord_char;
			let _str1 = String.fromCharCode(_chr);
			str = str + _str1;
		} else {
			let _chr = _ord_data - _ord_char;
			let _str1 = String.fromCharCode(_chr);
			str = str + _str1;
		}
	}
	return str;
}
