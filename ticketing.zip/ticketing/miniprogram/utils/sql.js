class sql {

  //构造函数
  constructor() {
    this.bootstart();
  }

  bootstart() {
    this.db = "";
    this.table = "";
    this.tables = [];
    this.options = {
      where: "",
      order: "",
      limit: ""
    };
  }

  name(name) {
    this.bootstart();
    this.table = name;
    return this;
  }

  async insert(data) {
    const self = this;
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection(self.table).add({
        data: data,
        success: res => {
          data._id = res._id
          reslove(data)
        },
        fail: err => {
          reject(err)
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  }

  async update(data) {
    const self = this;
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database();
      db.collection(self.table).doc(self.options['where']).update({
        data: data,
        success: res => {
          console.log(res);
          reslove(res)
        },
        fail: err => {
          console.error('[数据库] [更新记录] 失败：', err)
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      return false;
    })
    return resource;
  }

  async delete() {
    const self = this;
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection(self.table).doc(self.options['where']).remove({
        success: res => {
          console.log(res);
          reslove(res)
        },
        fail: err => {
          reslove(err)
          console.error('[数据库] [删除记录] 失败：', err)
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      return false;
    })
    return resource;
  }

  async select() {
    const self = this;
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection(self.table).where(self.options['where']).get({
        success: function(res) {
          reslove(res.data)
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  }

  /**
   * 指定查询条件
   * @param  {[type]} field     查询字段
   * @param  {[type]} op        查询表达式
   * @param  {[type]} condition 查询条件
   * @return {[type]}           [description]
   */
  where(field, op = null, condition = null) {
    this.options['where'] = field;
    //1.字符分割拆解
    return this;
  }

  limit(limit) {
    this.options['limit'] = limit;
    return this;
  }

  async first() {
    const self = this;
    let returned = new Promise(function(reslove, reject) {
      const db = wx.cloud.database()
      db.collection(self.table).where(self.options['where']).get({
        success: function(res) {
          reslove(res.data[0])
        }
      })
    })
    let resource = await returned.then((data) => {
      return data;
    }, (err) => {
      console.log('失败' + err)
    })
    return resource;
  }

}

module.exports = new sql();